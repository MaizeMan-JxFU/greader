from greader import hmpreader,genotype2vcf,vcfreader

geno = vcfreader('test.vcf')
geno = hmpreader('genotype.hmp')
print(geno)