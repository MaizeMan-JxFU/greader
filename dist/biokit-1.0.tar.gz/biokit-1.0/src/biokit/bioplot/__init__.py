# from . import base
from .pcshow import *
from .manhanden import *
from .sci_set import *

__name__ = 'Genotype Reader'
__version__ = '1.0'